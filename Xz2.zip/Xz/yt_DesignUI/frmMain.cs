﻿// Это форма для тестов
// This from for tests


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;
using Gui.Components;
using Gui.Controls;

namespace Gui
{
    public partial class frmMain : ShadowedForm
    {
        WebClient client = new WebClient();
        public frmMain()
        {
            InitializeComponent();

            Animator.Start();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (client.DownloadString("https://raw.githubusercontent.com/mrbean271/1/main/2.0").Contains("2.0"))
            {
                // Пропускаем
                MessageBox.Show("У вас актуальная версия", ":)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Обновляем
                MessageBox.Show("У вас старая версия", ":(", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            if (client.DownloadString("https://raw.githubusercontent.com/mrbean271/1/main/2.0").Contains("2.0"))
            {
                // Пропускаем
                MessageBox.Show("У вас актуальная версия", ":)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Обновляем
                MessageBox.Show("У вас старая версия", ":(", MessageBoxButtons.OK, MessageBoxIcon.Information);
                client.DownloadFile("", "update.exe");
                Application.Exit();
            }
        }
    }
}
